﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VenceParkingGarage.Core.Domain
{
    public enum VehicleType
    {
        Car = 1,
        Motorbike = 2
    }
}
