﻿using System;

namespace VenceParkingGarage.Application
{
    public class Class1
    {
    }
}
