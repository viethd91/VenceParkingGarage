﻿using System;

namespace VenceParkingGarage.Infrastructure
{
    public class Class1
    {
    }
}
