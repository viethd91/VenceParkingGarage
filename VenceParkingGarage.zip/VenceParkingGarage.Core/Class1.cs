﻿using System;

namespace VenceParkingGarage.Core
{
    public class Class1
    {
    }
}
